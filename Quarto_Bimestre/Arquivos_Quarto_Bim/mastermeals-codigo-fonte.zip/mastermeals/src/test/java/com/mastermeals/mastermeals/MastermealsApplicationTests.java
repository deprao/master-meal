package com.mastermeals.mastermeals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MastermealsApplicationTests {

	@Test
	void contextLoads() {
	}

}
