package com.mastermeals.mastermeals.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mastermeals.mastermeals.models.Receita;
import com.mastermeals.mastermeals.repositories.ReceitaRepository;
import com.mastermeals.mastermeals.repositories.ReceitasRepository;

@Controller
public class ReceitasController {

	@Autowired
	ReceitasRepository rr;
			
	@Autowired
	ReceitaRepository unicaReceita;
	
	Random random = new Random();
	
	String receitas[] = {"Bife à Parmegiana", "Bolo de Cenoura", "Camarão na Moranga", "Filé de Peixe Assado", "Pastel de Frango"};
	
	@RequestMapping(value="/menu", method=RequestMethod.GET)
	public String menu(Model model) {
		return("eventos/menu");
	}
	
	
	@RequestMapping(value="/buscarReceita", method=RequestMethod.GET)
	public String formBuscar(Model model) {
		List<Receita> receitas = new ArrayList<Receita>();
		model.addAttribute("receitas", new Receita());
		return("eventos/encontrarReceita");
	}
	
	@RequestMapping(value="/receitaSurpresa", method=RequestMethod.GET)
	public String formSurpresa(Model model) {
		List<Receita> receitas = new ArrayList<Receita>();
		model.addAttribute("receitas", new Receita());
		return("eventos/receitaSurpresa");
	}
	
	@RequestMapping(value="/receitaSurpresa", method=RequestMethod.POST)
	public ModelAndView receitaSurpresa() {
		ModelAndView mv = new ModelAndView("eventos/receitaSurpresa");
		List<Receita> receitas = new ArrayList<Receita>();
		int idAleatorio = random.nextInt(5);
		receitas = rr.findByNome(this.receitas[idAleatorio]);
		mv.addObject("receitas", receitas);
		return mv;
	}
	
	@RequestMapping(value="/buscarReceita", method=RequestMethod.POST)
	public ModelAndView buscarReceita(@RequestParam(value="nome", required=false, defaultValue="") String nome) {
		ModelAndView mv = new ModelAndView("eventos/encontrarReceita");
		List<Receita> receitas = new ArrayList<Receita>();
		receitas = rr.findByNome(nome);
		mv.addObject("receitas", receitas);
		return mv;
	}
	
	@RequestMapping(value="/detalhesReceita/{nome}", method=RequestMethod.GET)
	public ModelAndView detalhesReceita(@PathVariable("nome") String nome){
		Receita receita = unicaReceita.findByNome(nome);
		ModelAndView mv = new ModelAndView("eventos/detalhesReceita");
		mv.addObject("receita", receita);
	
		return mv;
	}
	
}
