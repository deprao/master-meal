package com.mastermeals.mastermeals.models;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="receitas")
public class Receita implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	private String nome;
	
	private String tempo_preparo;
	private float avaliacao;
	private String senha_conta;
	private String email_conta;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTempo_preparo() {
		return tempo_preparo;
	}
	public void setTempo_preparo(String tempo_preparo) {
		this.tempo_preparo = tempo_preparo;
	}
	public float getAvaliacao() {
		return avaliacao;
	}
	public void setAvaliacao(float avaliacao) {
		this.avaliacao = avaliacao;
	}
	public String getSenha_conta() {
		return senha_conta;
	}
	public void setSenha_conta(String senha_conta) {
		this.senha_conta = senha_conta;
	}
	public String getEmail_conta() {
		return email_conta;
	}
	public void setEmail_conta(String email_conta) {
		this.email_conta = email_conta;
	}
	
}
