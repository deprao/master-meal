package com.mastermeals.mastermeals.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mastermeals.mastermeals.models.Usuario;
import com.mastermeals.mastermeals.repositories.UsuarioRepository;
import com.mastermeals.mastermeals.security.UserService;

@Controller
public class CadastroUsuarioController {
	
	@Autowired
	UsuarioRepository usuarioRepository;
	
	@Autowired
	private UserService service;
	
	@RequestMapping(value="/cadastrarUsuario", method=RequestMethod.GET)
	public String form(Model model) {
		model.addAttribute("usuario", new Usuario());
		return("eventos/formCadastro");
	}
	
	@RequestMapping(value="/cadastrarUsuario", method=RequestMethod.POST)
	public String form(Usuario usuario) {
		service.registerUser(usuario);
		return "redirect:/cadastrarUsuario";
	}
	
	@RequestMapping(value="/loginUsuario", method=RequestMethod.GET)
	public String login () {
		return("eventos/loginUsuario");
	}

}
