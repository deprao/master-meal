package com.mastermeals.mastermeals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MastermealsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MastermealsApplication.class, args);
	}

}
