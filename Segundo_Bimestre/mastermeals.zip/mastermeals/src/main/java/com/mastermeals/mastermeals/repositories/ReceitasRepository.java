package com.mastermeals.mastermeals.repositories;

import org.springframework.data.repository.CrudRepository;

import com.mastermeals.mastermeals.models.Receita;

public interface ReceitasRepository extends CrudRepository<Receita, String>{
	
}
